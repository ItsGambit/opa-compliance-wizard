#!/bin/bash
# deploy.sh handoff protocol: 2
